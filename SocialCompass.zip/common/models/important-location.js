'use strict';

module.exports = function(Importantlocation) {

};
